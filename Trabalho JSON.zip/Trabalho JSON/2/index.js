var music = {
        nameMusic: "Toccata and Fugue in D minor",
        compositorName: "Johann Sebastian Bach",
        genre: "Classical",
        duration: "9min21s"
      }
console.table(music);
