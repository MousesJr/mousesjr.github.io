function success(pos) {
  var crd = pos.coords;
  var coordenate = {
    longitude: crd.longitude,
    latitude: crd.latitude
  }
  console.log(coordenate.longitude);
  console.log(coordenate.latitude);
  var longitude = document.getElementById('longitude');
  var latitude = document.getElementById('latitude');
  longitude.textContent = coordenate.longitude;
  latitude.textContent = coordenate.latitude;
};
navigator.geolocation.getCurrentPosition(success);
