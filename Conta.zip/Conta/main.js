console.log("main.js");
var e = "";
function Conta(saldo=500){
  this.saldo = saldo;
  this.historico = [`Abertura: R$${saldo}`];
  this.sacar= function sacar (valor_saque){
    console.log(this.saldo);
    if((valor_saque<=this.saldo)&&(valor_saque>=5)){
      this.saldo -= valor_saque;
      this.historico.push(`Saque: -R$${valor_saque}`);
      return true;
    } else {
      console.log("O saque deve ser maior que 5 reais ou maior que o saldo dispoível");
      return false;
    }
  }
  this.depositarDinheiro = function depositarDinheiro (valor_deposito){
    if(valor_deposito<=1000){
      this.saldo += valor_deposito;
      this.historico.push(`Depósito em dinheiro: +R$${valor_deposito}`);
      return true;
    } else {
      console.log("O deposito em dinheiro deve ser menor ou igual a R$1000, não podendo exceder este limite");
      return false;
    }
  }
  this.depositarCheque = function depositarCheque (valor_deposito){
    if(valor_deposito<=10000){
      this.saldo += valor_deposito;
      this.historico.push(`Depósito em cheque: +R$${valor_deposito}`);
      return true;
    } else {
      console.log("O deposito em cheque deve ser menor ou igual a R$10000, não podendo exceder este limite ");
      return false;
    }
  }
  this.transfere = function transfere (valor_transferencia, conta){
    if(valor_transferencia<=5000){
      if(this.saldo>=valor_transferencia){
        this.saldo -= valor_transferencia;
        conta.saldo += valor_transferencia;
        this.historico.push(`Transferência: -R$${valor_transferencia}`);
        conta.historico.push(`Transferência: +R$${valor_transferencia}`);
        return true;
      } else{
        throw "Saldo insuficiente para transferência";
        e="Saldo insuficiente para transferência";
      }
    } else {
      e = "Transferência excede o limite de 5000";
      throw "Transferência excede o limite de 5000";
      return false;
    }
  }
}

const conta1 = new Conta();
// saldo inicial de 500
console.log(conta1.saldo); // 500
console.log(conta1.saldo === 500);
console.log(conta1.historico.length === 1);
console.log(conta1.historico[0] === "Abertura: R$500");
// não é permitido
console.log(conta1.sacar(600) === false);
console.log(conta1.saldo); // 500
console.log(conta1.saldo === 500);
console.log(conta1.historico.length === 1);
// é permitido
console.log(conta1.sacar(60) === true); // 500 - 60 === 440
console.log(conta1.saldo); // 440
console.log(conta1.saldo === 440);
console.log(conta1.historico.length === 2);
console.log(conta1.historico[0] === "Abertura: R$500");
console.log(conta1.historico[1] === "Saque: -R$60");
// não é permitido
console.log(conta1.sacar(4) === false);
console.log(conta1.saldo); // 440
console.log(conta1.saldo === 440);
console.log(conta1.historico.length === 2);

// até aqui 0.5 pontos <=========================================

// depósito em dinheiro não permitido
console.log(conta1.depositarDinheiro(1100) === false);
console.log(conta1.saldo); // 440
console.log(conta1.saldo === 440);
console.log(conta1.historico.length === 2);
// depósito em dinheiro permitido
console.log(conta1.depositarDinheiro(500) === true); // 440 + 500 === 940
console.log(conta1.saldo); // 940
console.log(conta1.saldo === 940);
console.log(conta1.historico.length === 3);
console.log(conta1.historico[0] === "Abertura: R$500");
console.log(conta1.historico[1] === "Saque: -R$60");
console.log(conta1.historico[2] === "Depósito em dinheiro: +R$500");
// depósito em cheque não permitido
console.log(conta1.depositarCheque(11100) === false);
console.log(conta1.saldo); // 940
console.log(conta1.saldo === 940);
console.log(conta1.historico.length === 3);
// depósito em cheque permitido
console.log(conta1.depositarCheque(5000) === true); // 940 + 5000 === 5940
console.log(conta1.saldo); // 5940
console.log(conta1.saldo === 5940);
console.log(conta1.historico.length === 4);
console.log(conta1.historico[0] === "Abertura: R$500");
console.log(conta1.historico[1] === "Saque: -R$60");
console.log(conta1.historico[2] === "Depósito em dinheiro: +R$500");
console.log(conta1.historico[3] === "Depósito em cheque: +R$5000");

console.log("________________________________________________________________");
const conta2 = new Conta(800);
console.log(conta2.saldo === 800); // true

try {
  const conta3 = new Conta(499); // throws an exception
  console.log(false); // essa linha não deve ser alcançada
} catch(e) { // a exceção deve ser capturada
  console.log(e); // saldo inicial invalido
  console.log(e === "saldo inicial invalido"); // true
}

// transferência válida
console.log(conta1.transfere(1000, conta2) === true);
console.log(conta1.saldo === 4940);
console.log(conta2.saldo === 1800);

console.log(conta1.historico.length === 5);
console.log(conta1.historico[0] === "Abertura: R$500");
console.log(conta1.historico[1] === "Saque: -R$60");
console.log(conta1.historico[2] === "Depósito em dinheiro: +R$500");
console.log(conta1.historico[3] === "Depósito em cheque: +R$5000");
console.log(conta1.historico[4] === "Transferência: -R$1000");

console.log(conta2.historico.length === 2);
console.log(conta2.historico[0] === "Abertura: R$800");
console.log(conta2.historico[1] === "Transferência: +R$1000");

const conta4 = new Conta(2000);
try {
  console.log(conta4.transfere(2001, conta2));
  console.log(false); // essa linha não deve ser alcançada
} catch (e) {
  console.log(e === "Saldo insuficiente para transferência");
}

try {
  console.log(conta4.transfere(5001, conta2));
  console.log(false); // essa linha não deve ser alcançada
} catch (e) {
  console.log(e === "Transferência excede o limite de 5000");
}
