var ticket_price = document.getElementById('ticket_price');
var output_full_price = document.getElementById('output_full_price');
var output_half_price = document.getElementById('output_half_price');
var subtotal = document.getElementById('subtotal');
var table = document.getElementById('table');
var full_tickets = document.getElementById('full_tickets');
var half_tickets = document.getElementById('half_tickets');
var n_half_price = 0;
var n_full_price = 0;
var n_half_qtd = 0;
var n_full_qtd = 0;
var total = 0;

ticket_price.addEventListener('keyup', function () {
  n_full_price = ticket_price.value;
  n_half_price = n_full_price/2;
  if (ticket_price.value === '') {
    output_full_price.textContent = 'R$ 0';
    output_half_price.textContent = 'R$ 0';
    subtotal.textContent = 'R$ 0';
  } else {
    output_full_price.textContent = 'R$ '+ n_full_price;
    output_half_price.textContent = 'R$ '+ n_half_price;
  }
});

table.addEventListener('click', function (evento) {
  var chair;
  if (evento.target.src.includes('chair.jpg')) {
    chair = evento.target;
    chair.src = 'chair_full_price.png';
    n_full_qtd++;
    full_tickets.textContent = n_full_qtd;
  } else if (evento.target.src.includes('chair_full_price.png')) {
    chair = evento.target;
    chair.src = 'chair_half_of_the_price.png';
    n_full_qtd--;
    n_half_qtd++;
    full_tickets.textContent = n_full_qtd;
    half_tickets.textContent = n_half_qtd;
  } else if (evento.target.src.includes('chair_half_of_the_price.png')) {
    chair = evento.target;
    chair.src = 'chair.jpg';
    n_half_qtd--;
    half_tickets.textContent = n_half_qtd;
    full_tickets.textContent = n_full_qtd;
  }
  subtotal.textContent = 'R$ ' + ((n_full_price * n_full_qtd) + (n_half_price * n_half_qtd));
});

/*
Mouses, pra mudar de imagem, devo mudar de src, e para isso devo saber qual é a src de início, na qual estou clicando. Deverei testar por if, com isso irei usar evento.target.src. acontece q isso irá me retornar TODO o caminho da src, 'C://Mouses//ETC/DBO/Cinema/chair.png'
*/
