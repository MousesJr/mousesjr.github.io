var table = document.querySelector('table');
// table.onclick = function () {
//   alert('Click!');
// }
table.addEventListener('click', function(evento){ //Does something when the event is activated
  console.log(this); //this is the object that executed the function. Is a var that exists without necessarity of beeing created by the programmer
  console.log(evento);
  var cell = evento.target;
  cell.className = 'pt';
});
